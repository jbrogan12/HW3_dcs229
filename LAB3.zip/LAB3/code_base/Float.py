from Number import Number

######################################################################
class Float(Number):

    def __init__(self, value: float | int, digits: int = 2) -> None:
        ''' initializer method for Float class
        Parameter:
            value: a float or integer
            digits: an integer representing # of digits beyond
                decimal to be displayed when printing
        Raises:
            ValueError if value cannot be converted to float
        '''
        pass # your code instead

    def __add__(self, other: Number | int | float) -> Number:
        # you are likely to need Integer in here, so do a local-to-method
        # import (rather than global at the top) to avoid circular imports
        # (see Integer.py for an example that imports Float locally)
        pass

    def __mul__(self, other: Number | int | float) -> Number:
        # you are likely to need Integer in here, so do a local-to-method
        # import (rather than global at the top) to avoid circular imports
        # (see Integer.py for an example that imports Float locally)
        pass

    def changeFormat(self, digits: int) -> None:
        ''' for this object, sets the number of digits to appear after the
            decimal when printed
        Parameters:
            digits: integer number of digits to appear after the decimal
        Raises:
            ValueError if digits cannot be converted to int
        '''
        pass

    def __str__(self) -> str:
        ''' returns a string representation of the Float object,
            formatted to the Float-object-specified digits of
            precision
        Returns:
            a string of the formatted Float, e.g., "3.1416"
            if the Float object's data contains 3.1415926535
            and the digits of precision had been changed to 4
        '''
        # use f-string float formatting;
        # see https://realpython.com/how-to-python-f-string-format-float/
        pass

